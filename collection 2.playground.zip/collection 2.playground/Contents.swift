

var myCollection:[String] = ["manga"]
// instead of setting up a empty array its better to use what you know already
myCollection.append ("picture frame")
myCollection += ["pens"]
// Not sure how to change up the wording this is the best i can do at the momment
print("myCollection contains \(myCollection.count) items.")
if myCollection.isEmpty{
    print("There is nothing in My collection")
} else {
    print("There a few are items in My collection")
}
